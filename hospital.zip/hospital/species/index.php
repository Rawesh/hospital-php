<?php
	include "../common/header.php";
?>
	<h1>Species</h1>
	<p>to be implemented soon</p>
	
<?php
	include "../common/footer.php";
?>