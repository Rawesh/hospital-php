<?php
	include "../common/header.php";
?>
	<h1>Hospital</h1>
	<ul>
		<li><a href="../patients/index.php">Patiënts</a></li>
		<li><a href="../clients/index.php">Clients</a></li>
		<li><a href="../species/index.php">Species</a></li>
	</ul>
	
<?php
	include "../common/footer.php";
?>