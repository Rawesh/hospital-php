<?php
	include "../common/header.php";
?>
		<h1>Page not found</h1>
		<p><a href="../">Home</a></p>
		
<?php
	include "../common/footer.php";
?>